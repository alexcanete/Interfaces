package start;

import view.FrmPrincipal;

public class Start {

	public static void main(String[] args) throws Exception {

		FrmPrincipal frame = new FrmPrincipal();
		frame.setVisible(true);
	}

}
