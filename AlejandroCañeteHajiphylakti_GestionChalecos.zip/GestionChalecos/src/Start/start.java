package Start;

import view.FrmPrincipal;

public class start {

	public static void main(String[] args) {
		
		FrmPrincipal frame = new FrmPrincipal();
		frame.setVisible(true);
				
	}
}
